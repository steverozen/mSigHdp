library(testthat)
library(mSigHdp)

test_check("mSigHdp")
